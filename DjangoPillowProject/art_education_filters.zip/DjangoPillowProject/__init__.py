"""
Package for DjangoPillowProject.
"""
